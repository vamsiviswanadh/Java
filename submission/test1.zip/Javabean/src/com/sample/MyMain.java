package com.sample;

import java.sql.PreparedStatement;
import java.util.Scanner;

public class MyMain {

	void getInputs() {

		Scanner in = new Scanner(System.in);
		System.out.println("Enter the number of Employees");
		int arrSize = in.nextInt();
		Employee[] empArr = new Employee[arrSize];

		for (int i = 0; i < empArr.length; i++) {
			
			System.out.println("Enter the Employee details \n Enter the empId");
			int empId = in.nextInt();

			System.out.println("Enter the Emp Fname ");
			String empFName = in.next();

			System.out.println("Enter the Emp Lname ");
			String empLName = in.next();

			System.out.println("Enter the Emp email ");
			String empMail = in.next();

			System.out.println("Enter the emp salary");
			int empSal = in.nextInt();
			
			Employee emp = new Employee(empId, empFName, empLName, empSal);
			empArr[i] = emp;
			
			

		}

	}

	public static void main(String[] args) {
		MyMain mymain = new MyMain();
		mymain.getInputs();
	}

}
