package com.example;

public class SuperClass {

	 public void printMe()
	{
		System.out.println("I am from SuperClass");
	}
	

}
