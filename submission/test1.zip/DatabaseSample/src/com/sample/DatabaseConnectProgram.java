package com.sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnectProgram {
	
	
	// Credentials 
	static String user = "root";
	static String pwd= "root";
	static String URL="jdbc:mysql://localhost:3306/javatraining";
		

	public DatabaseConnectProgram() {
		
	}

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(URL,user,pwd);
			Statement stmt= con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from student");
			
			while(rs.next())
			{
				System.out.print(rs.getInt(1) + "   ");
				System.out.print(rs.getString(2) + "   ");
				System.out.print(rs.getString(3) + "   ");
				System.out.print(rs.getInt(4) + "   \n");
			}
			
			con.close();
			
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} // Connect driver
		
		
		
	}

}
