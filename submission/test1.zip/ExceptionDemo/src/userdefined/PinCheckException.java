package userdefined;

@SuppressWarnings("serial")
public class PinCheckException extends  Exception {

	@Override
	public String getMessage() {
		
		return "Pin code is not valid ";
	}
	
	
}
