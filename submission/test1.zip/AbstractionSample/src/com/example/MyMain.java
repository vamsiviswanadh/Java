package com.example;

public class MyMain {

	public static void main(String[] args) {
		SuperClass superClass = new SuperClass();
		SubClass subClass = new SubClass(); 
		
		subClass.printMe();
		superClass.printMe();

	}

}
