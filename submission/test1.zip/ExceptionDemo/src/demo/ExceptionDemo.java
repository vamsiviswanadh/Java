package demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExceptionDemo {

	public static void main(String[] args) {
		int[] myarr = new int[2];
		try {
			FileInputStream fs = new FileInputStream("C:\\Users\\vamsi\\OneDrive\\Documents\\hello.txt");
			
			
			
			myarr[0] =234234; 
			
			System.out.println("No exception");
			
			
		} 	catch ( FileNotFoundException e) {
			
			e.printStackTrace();
		}  // Checked Exception
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			myarr[1]=234234;
			System.out.println("Array Exception handed ");
		}
		catch (Exception e)
		{
			System.out.println("this is generic");
		}
		finally {
			System.out.println("This will be executed even if exception ");
		}
	

	}

}
