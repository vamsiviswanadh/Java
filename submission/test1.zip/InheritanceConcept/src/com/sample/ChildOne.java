package com.sample;

public class ChildOne  {

	String depart; 
	String hod; 
	
}
