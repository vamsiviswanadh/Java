package com.sample;

public class ClassB extends ClassA {

	String stringVarB ; 
	int intVarB;
	
	void printFromB()
	{
		System.out.println("Printing from B");
	}
	
	
	void sum(int a, int b)
	{
		System.out.println(a+b);
	}
	
}
