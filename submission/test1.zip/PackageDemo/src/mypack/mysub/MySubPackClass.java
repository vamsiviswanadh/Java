package mypack.mysub;

public class MySubPackClass {

}
