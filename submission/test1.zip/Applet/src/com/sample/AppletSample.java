package com.sample;

public class AppletSample extends Applet{

}
