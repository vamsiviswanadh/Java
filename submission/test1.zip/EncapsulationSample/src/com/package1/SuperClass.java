package com.package1;

public class SuperClass {
	
	String strDefault = "I am from super default"; 
	
	private String strPrivate = "I am from super private"; 
	
	public String strPublic = "I am from super public"; 
	
	protected String strProtect = "I am from super procted"; 
	
	
	void myMthod ()
	{
		SuperClass sp = new SuperClass();
		
	}
	
}
