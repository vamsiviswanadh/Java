package com.sample;

public class MyMainClass {

	public static void main(String[] args) {
		
		MyInterface impl = new MyImplementation();
		int result= impl.sum(15,25);
		System.out.println(result);
		
		int result1= impl.sum(150,250);
		System.out.println(result1);
		
		float result2= impl.sum(15.25f,25.55f);
		System.out.println(result);
		
		
		
		String name = impl.myName();
		System.out.println("my name is "+name);
		
		
		
		
	}

}
