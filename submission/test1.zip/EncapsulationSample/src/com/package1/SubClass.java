package com.package1;

public class SubClass extends SuperClass{

	void mymethod()
	{
		SuperClass spClass= new SuperClass();
		spClass.
	}
	
	
}
