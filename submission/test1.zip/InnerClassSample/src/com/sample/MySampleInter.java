package com.sample;

public interface MySampleInter {

	public void printMe(); // Declaration
	
}
