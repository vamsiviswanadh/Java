package com.sample;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StudentRecord stu = new StudentRecord();
		
		StudentRecord stu1 = new StudentRecord(12312, "Vamsi", "CSE");
		StudentRecord stu2 = new StudentRecord(45455, "Aarav", "Aero");

		
		
		StudentRecord[] myStudents = new StudentRecord[5];
		for(int i=0 ; i<5 ; i++)
		{
		//	int roll = Scanne. in ();
			StudentRecord stu3 = new StudentRecord(12312, "Vamsi", "CSE");
			myStudents[i]= stu3;
		}
		
		
	}

}
