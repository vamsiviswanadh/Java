package com.package2;

import com.package1.SuperClass;

public class AnotherSubClass extends SuperClass {

	void myMethod()
	{
		SuperClass spClass= new SuperClass();
		
	}
	
}
