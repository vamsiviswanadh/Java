package com.sample;

public interface MyInterface {

	abstract int sum(int a, int b);
	float sum(float a, float b);
	public String myName();
}
