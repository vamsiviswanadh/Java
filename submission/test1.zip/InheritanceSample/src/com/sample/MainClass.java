package com.sample;

public class MainClass {

	public static void main(String[] args) {
		
		ClassC cObj = new ClassC(); 
		
		cObj.sum(10, 10);
		
		
		ClassB bObj = new ClassB();
		
		bObj.sum(10,10);
		
		ClassA aObj = new ClassA();
		
	
		AbstractClassC absC = new ClassC();
		absC.printFromC();
	}
	
	//Overloading -- Static Polymorphism
	
	void add ()
	{
		System.out.println("5+10=15");
	}
	
	void add (int a, int b)
	{
		System.out.println("a+b="+ (a+b));
	}

	void add (String a, String b)
	{
		System.out.println(a+b);
	}
}
