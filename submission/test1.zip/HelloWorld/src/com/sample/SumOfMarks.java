package com.sample;

public class SumOfMarks {

	public static void main(String[] args) {
		
		Integer[] marks = {10,20,-8,-25,58,66,-9,-1,5,-3};
		
		int sumOfNegative=0, sumOfPositive=0; 
		
		
		for (int mark: marks) // foreach loop
		{
			
			if(mark < 0)
			{
				sumOfNegative = sumOfNegative + mark; 
			}
			else
			{
				sumOfPositive= sumOfPositive+mark; 
			}
			
			
		}
		
		System.out.println("sumOfPositive = "+ sumOfPositive);
		System.out.println("sumOfNegative = "+ sumOfNegative);
		
		//System.out.println("sumOfNegative = "+ -sumOfNegative);

		int val = Math.abs(sumOfNegative);
		
		
		if (sumOfPositive > val ) // 159 < 46
		{
			System.out.println("sumOfPositive is greater");
		}
		else
		{
			
				System.out.println("sumOfNegative is greater");
			
		}
		

	}

}
