package com.sample;

import java.util.Arrays;
import java.util.Scanner;

public class StringArraySample {

	public static void main(String[] args) {
		// Design a Java program that reads 
	 // an array of strings and creates a new array with strings 
		//arranged based on the number of characters it contains. 
		//If the number of characters is same, then the order of words appear 
		//in the new array should be same as in the original array.
		//For example, if the array contains ("Now", "is", "the", "time", "to", "act!"), 
		//then the new string array should contain ("is", "to", "Now", "the", "time", "act!"}. 
		//Implement the scenario using character stream.

		
		Scanner in=new Scanner(System.in);
		System.out.println("enter the size of array");
		int sizeofarray= in.nextInt();
		String[] strarray = new String[sizeofarray];
		for (int i=0;i<sizeofarray;i++)
		{
			System.out.println(" enter the string "+i);
			strarray[i]= in.next();
		}
		System.out.println(strarray.toString());
	for (String S:strarray)
	{
		System.out.println(S);
	}
	Arrays.sort(strarray);
	for (String S:strarray)
	{
		System.out.println(S);
	}
	
	}
	

}
