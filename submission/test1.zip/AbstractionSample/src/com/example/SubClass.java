package com.example;

public class SubClass extends SuperClass {

	public void printMe()
	{
		System.out.println("I am from SubClass");
	}
	
	
}
