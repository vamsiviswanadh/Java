package com.sample;

public class ParentClass {

	String college; 
	String area; 
	
	
	
}
