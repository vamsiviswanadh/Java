package com.sample;

public class StudentRecord extends ParentClass{

	int rollId; 
	String name; 
	String dept; 
	
	// Constructor is used to initialize 
	// Constructor must be in the name of Class name. 
	// Constructor is a method which will execute at the time of object creation 
	
	// 3 types -- Default constructor.. pre defined 
	// No args constructor 
	
	StudentRecord()
	{
		System.out.println("Welcome student");
	}
	
	// Parameterized constructor 
	StudentRecord(int roll, String stName, String depart)
	{
		this.rollId = roll; 
		this.name = stName;
		this.dept= depart; 
		super.college="VIT";
		super.area="Chennai";
	}

	
	
}
