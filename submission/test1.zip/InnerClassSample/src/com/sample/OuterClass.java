package com.sample;

public class OuterClass {


	// Member Inner Class 
	public class InnerClass{
		
		String myStr = "In am from inner";
		
	}
	
	//Local inner Class 
	void myMethod()
	{
		 class LocalInnerClass
		{
			String str = "my str";
			
			
			void myInnerMethod()
			{
				System.out.println("Hello ");
			}
			
		}
		 
		 
		LocalInnerClass lcin = new LocalInnerClass();		
		 lcin.myInnerMethod();
		 
	}
	
	
	
}
