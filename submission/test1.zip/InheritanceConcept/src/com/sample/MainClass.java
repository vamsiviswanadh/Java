package com.sample;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ChildTwo stu = new ChildTwo("Vamsi", 23424); 
		ChildOne st = new ChildOne();
		
		
		
	}

}
