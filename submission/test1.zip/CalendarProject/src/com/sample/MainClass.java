package com.sample;

public class MainClass {

	public static void main(String[] args) {
		CalendarProgram calendar = new CalendarProgram(29,"FEB", 2021 , "21:01:00 IST");
		calendar.displayDate();

	}

}
