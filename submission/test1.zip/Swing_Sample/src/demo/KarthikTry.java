package demo;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import demo.db.LoginCheck;

public class KarthikTry {

	public static void main(String[] args) {
		JFrame  jf=new JFrame("Karthik login page");
		jf.setSize(500,200);
		jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JPanel mypanel= new JPanel();
		jf.add(mypanel);
		mypanel.setLayout(null);
		
		
		
		JLabel userlable=new JLabel("your name");
		userlable.setBounds(10,20,180,30);
		mypanel.add(userlable);
		
		JLabel passlable=new JLabel("Password type karo");
		passlable.setBounds(10,50,180,30);
		mypanel.add(passlable);
		JTextField usertext=new JTextField();
		usertext.setBounds(200,20,180,25);
		mypanel.add(usertext);
		JPasswordField passfield=new JPasswordField();
		passfield.setBounds(200,50,180,25);
		mypanel.add(passfield);
		JButton login=new JButton("LOGIN");
		login.setBounds(200,85,100,25);
		mypanel.add(login);
		login.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				
				JLabel stLab=new JLabel();
				stLab.setBounds(200,120,180,25);
				mypanel.add(stLab);
				
				String user = usertext.getText();
				String pass = passfield.getText();
				
				LoginCheck loginCheck = new LoginCheck(); 
				boolean status = loginCheck.validateLogin(user, pass);
				
				if(status == true) {
					stLab.setText("");
				stLab.setText("Login: Success");
				System.out.println("Login success");
				}
				else{
					
					stLab.setText("Login: Failed");
					System.out.println("Login Failed");
					}
					
			}
			
		});
		
		
		jf.setVisible(true);


		
	}

}
