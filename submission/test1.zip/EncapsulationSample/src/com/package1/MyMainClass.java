package com.package1;

import com.package2.AnotherSubClass;

public class MyMainClass {

	public static void main(String[] args) {
		
		SuperClass spClass= new SuperClass();
		
		AnotherSubClass anothSub= new AnotherSubClass();
		
		anothSub.strProtect;

	}

}
