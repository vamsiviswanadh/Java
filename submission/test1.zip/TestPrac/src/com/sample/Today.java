package com.sample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Today{
	
	
	// Credentials 
	static String user = "root";
	static String pwd= "root";
	static String URL="jdbc:mysql://localhost:3306/World";
		

	public void today() {
		
	}

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(URL,user,pwd);
			Statement stmt= con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from Examination");
			
			while(rs.next())
			{
				System.out.print(rs.getInt(1) + "   ");
				System.out.print(rs.getString(2) + "   ");
				System.out.print(rs.getInt(3) + "   \n");
			}
			
			con.close();
			
			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} // Connect driver
		
		
		
	}

}
