package com.sample;

public class HelloCollege {

	int x=10; // Memeber Variables 
	
	
	//Main method
	public static void main(String[] args) {
		
		int y =333; // Local variabls 
		
		Integer uu = 23424; // Also known as Wrapper classes 
		
		
		System.out.println("y++" + y++ ); // print the y value and then increment
		
		System.out.println("y =="+ y);
		
		System.out.println("++y" + ++y );
		
		System.out.println("y =="+ y);
		
		
		// TODO Auto-generated method stub
		System.out.println("Welcome to Java world "+args[0]);
	}

}
