package mypack.mysub1;

public class MySubPackClass {

}
