package com.sample;

public class Employee {

	// Properties 
	private int empId; 
	private String empFName;
	private String empLName;
	private int salary;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpFName() {
		return empFName;
	}
	public void setEmpFName(String empFName) {
		this.empFName = empFName;
	}
	public String getEmpLName() {
		return empLName;
	}
	public void setEmpLName(String empLName) {
		this.empLName = empLName;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Employee(int empId, String empFName, String empLName, int salary) {
		super();
		this.empId = empId;
		this.empFName = empFName;
		this.empLName = empLName;
		this.salary = salary;
	} 
	
	

}
