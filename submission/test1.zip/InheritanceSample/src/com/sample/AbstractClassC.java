package com.sample;

public abstract class AbstractClassC {

	abstract void printFromC();
	//abstract void sum(int a, int b);
	
}
