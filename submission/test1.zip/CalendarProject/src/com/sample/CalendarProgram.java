package com.sample;

public class CalendarProgram {

	int day;
	String month; 
	int year; 
	String time=  "20:52:45 IST";
	
	
	
	public CalendarProgram(int day, String month, int year, String time) {
		super();
		this.day = day;
		this.month = month;
		this.year = year;
		this.time = time;
	}


	public int getDay() {
		
		switch (this.month)
		{
		case "JAN":
			if (this.day>31)
			{
				System.out.println("Jan has only 31 days");
			}
			break;
			
		case "FEB":
			if(this.year % 4 == 0)
			{
				if(this.day>29)
				{
					System.out.println("Year is LEAP ");
				}
			}
			else
			{
				if(this.day>28)
				{
					System.out.println("Year is NOT LEAP ");
				}
			}
			break;
		
		
		
		}
		
		
		return day;
	}


	public void setDay(int day) {
		this.day = day;
	}


	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}


	public int getYear() {
		return year;
	}






	public void setYear(int year) {
		this.year = year;
	}






	public String getTime() {
		return time;
	}






	public void setTime(String time) {
		this.time = time;
	}


	public void displayDate()
	{
		System.out.println(getDay()+" / "+getMonth()+" / "+getTime());  //EEE, d MMM yyyy HH:mm:ss Z�
	}

}
