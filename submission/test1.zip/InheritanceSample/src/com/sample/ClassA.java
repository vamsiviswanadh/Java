package com.sample;

public class ClassA implements InterfaceForA {

	String stringVarA ; 
	int intVarA;
	
	public void printFromA()
	{
		System.out.println("Printing from A");
	}
	
	
}
