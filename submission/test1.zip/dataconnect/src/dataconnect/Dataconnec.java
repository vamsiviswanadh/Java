package dataconnect;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Dataconnec {

	static String user = "root";
	static String pwd = "root";
	static String URL = "jdbc:mysql://localhost:3306/employee";

	public Dataconnec() {

	}

	public static void main(String[] args) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javatraining", "root", "root");
			Statement stmt = con.createStatement();

			
			
			CallableStatement cs = con.prepareCall("call getVamsi()");
			ResultSet rs1= cs.executeQuery();
			
			while (rs1.next()) {
				System.out.print(rs1.getInt(1) + "   ");
				System.out.print(rs1.getString(2) + "   ");
				System.out.print(rs1.getString(3) + "   ");
				System.out.print(rs1.getString(4) + "   ");
				System.out.print(rs1.getInt(5) + "    \n");
			}
			Scanner in = new Scanner(System.in);
			
			
			PreparedStatement ps = con.prepareStatement("insert into employee values ( ?,?,?,?,?)");
			

			while (true) {
				System.out.println("Enter the Employee details \n Enter the empId");
				int empId = in.nextInt();

				System.out.println("Enter the Emp Fname ");
				String empFName = in.next();

				System.out.println("Enter the Emp Lname ");
				String empLName = in.next();

				System.out.println("Enter the Emp email ");
				String empMail = in.next();

				System.out.println("Enter the emp salary");
				int empSal = in.nextInt();

				ps.setInt(1, empId); // roll no
				ps.setString(2, empFName);
				ps.setString(3, empLName);
				ps.setString(4, empMail);
				ps.setInt(5, empSal);
				
				ps.addBatch();
				
				

				System.out.println("Do you want to enter another values ? y/n");
				String userIp = in.next();
				if (!"Y".equalsIgnoreCase(userIp)) {
					break;
				}

			}
			
			boolean status = ps.execute();

			// boolean status = stmt.execute("insert into employee values ( 212121, 'Raja',
			// 'Mari', 'raja@gmail.com', '60000')");

			//System.out.println(" Status of execute :" + status);

			ResultSet rs = stmt.executeQuery("select * from employee");

			while (rs.next()) {
				System.out.print(rs.getInt(1) + "   ");
				System.out.print(rs.getString(2) + "   ");
				System.out.print(rs.getString(3) + "   ");
				System.out.print(rs.getString(4) + "   ");
				System.out.print(rs.getInt(5) + "    \n");
			}

			con.close();

		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} // Connect driver

	}

}
