package com.sample;

public class ClassC extends AbstractClassC {

	String stringVarC ; 
	int intVarC;
	
	
	//Overriding -- Dynamic polymorphism 
	
	void printFromC()
	{
		
		
		System.out.println("Printing from C");
	}
	
	void sum(int a, int b)
	{
		System.out.println(a*b);
	}
	
}
