package com.sample;

public class TwoArr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[][] marks= {{90,80,85},{75,85,60},{100,55,60}};
for(int i=0; i<3;i++) {
	for(int j=0;j<3;j++) {
	System.out.print(marks[i][j]+" ");
		
	}
	System.out.println("\n");
	}
		
}
}
	


