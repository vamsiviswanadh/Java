package demo.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginCheck {

	public boolean validateLogin(String user, String pass )
	{

		String userName = user; 
		String password = pass; 
		Connection con;
		
		try
	    {
	        Class.forName("com.mysql.jdbc.Driver");
	       
	        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/javatraining","root","root");
	        PreparedStatement stmt = con.prepareStatement("select password from user where username = ?");
	        stmt.setString(1,userName);
	        ResultSet rs = stmt.executeQuery();
			
	        if(rs.next() && password.equals(rs.getString(1)))
	        {
	        	return true; 
	         }
	        else
	        {
	        	return false; 
	      
	      	}
	    }catch(Exception es)
	    {
	       		return false; 
	    }
	}
	
}
//user name