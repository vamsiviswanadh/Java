package mypack;

import mypack.mysub1.MySubPackClass;

public class MySampleApp {

	public static void main(String[] args) {
		System.out.println("this is My Pack");
		
		mypack.mysub1.MySubPackClass mysub = new MySubPackClass();

	}

}
