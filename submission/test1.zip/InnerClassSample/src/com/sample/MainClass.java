package com.sample;

import com.sample.OuterClass.InnerClass;

public class MainClass {

	static String mynickname="Vams" ;
	
	final  String myfinal = "sdfsdf";
	
	String myvar = "Hi there" ;
	
	void myMethod()
	{
		System.out.println("My nick name is "+mynickname);
	}
	
	
	
	public static void main(String[] args)
	{
		
		MainClass myob = new MainClass();
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		InnerClass innser = new OuterClass().new InnerClass();
		
		System.out.println("Hi there"); // Constant
		
		String myStr = "Hi there";
		System.out.println(myStr); // Variable 
		
		
		final String myname = "Vamsi" ; // Final variable 
		
		
		// Anonymous inner class 
		MySampleInter myin = new MySampleInter() {
			// Implementation
			@Override
			public void printMe() {
				System.out.println("I am printed from loctiosdkfj"+myname);
				myname ="sdfsdf";
			}
			
		
		};
			
			
			System.gc();
	}
	

	
}
