package com.sample;

public interface InterfaceForA {
	 void printFromA();
	
}
