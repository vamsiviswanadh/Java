package com.sample;

public class ChildTwo extends ChildOne{

	String student; 
	int roll ;
	public ChildTwo(String student, int roll) {
		super();
		this.student = student;
		this.roll = roll;
		super.depart="CSE";
		super.hod="Xyss";
	}
	 
	
	
	
	
	
}
