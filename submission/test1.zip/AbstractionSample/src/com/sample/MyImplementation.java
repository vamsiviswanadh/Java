package com.sample;

public class MyImplementation implements MyInterface{

	public int sum(int a, int b)
	{
		int c = a+b;
		
		return c;
		
	}
	
	
	public float sum(float a, float b)
	{
		return a+b;
	}
	
	
	public String myName()
	{
		
		String name = "VAmsi";
		
		return name;
	}
	
}
